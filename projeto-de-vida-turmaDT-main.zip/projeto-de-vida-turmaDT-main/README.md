

<!-- PROJECT LOGO -->
<br />
<div align="center">
  <a href="https://github.com/kheronn/projeto-de-vida-turmaDT">
    <img src="turmadt.png" alt="Logo" >
  </a>

<h3 align="center">Projeto de Vida - Turma DT</h3>

  <p align="center">
    Projeto construído no Grupo de Formadores Trilha de Programação II | 1ª Jornada de 2024
    <br />
    <a href="https://github.com/kheronn"><strong>Prof. Formador Kheronn Khennedy Machado</strong></a>
    <br />
    <br />
   
  </p>
</div>



<!-- TABLE OF CONTENTS -->
<details>
  <summary>Conteúdos</summary>
  <ol>
    <li>
      <a href="#about-the-project">Sobre o projeto</a>
      <ul>
        <li><a href="#built-with">Tecnologias</a></li>
      </ul>
    </li>   
  </ol>
</details>



<!-- ABOUT THE PROJECT -->
## Sobre o projeto





### Tecnologias

* [![HTML][HTML]][HTML]
* [![CSS][CSS]][CSS]
* [![Javascript][Javascript]][Javascript]



<!-- MARKDOWN LINKS & IMAGES -->
<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->
[turma]: turmadt.png
[HTML]: https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white
[CSS]: https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white
[Javascript]: https://img.shields.io/badge/logo-javascript-blue?logo=javascript